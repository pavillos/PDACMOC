# ADVOCATE
## Modification for PDACMOC (version 0.1.0.1)

This copy is distributed inside the PDACMOC package. The only change from version 0.1.0 is
that the number of parallel workers, previously fixed to 2 (`registerDoMC(2)`), is read from
the option `ADVOCATE.cores` (default 2). Results are not affected.
